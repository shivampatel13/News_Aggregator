from django import forms
from app1.models import userdet

class userform(forms.ModelForm):
    class Meta:
        model = userdet
        fields = "__all__"