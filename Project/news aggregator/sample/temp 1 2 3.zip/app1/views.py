from django.contrib import messages

from django.contrib import auth
from django.shortcuts import render,redirect
from django.http import HttpResponse
from app1.models import userdet
from app1.form import userform
# Create your views
# here.



def show(request):
    return HttpResponse("<h1>This is my first application function</h1>")

def show1(request):
    return HttpResponse("<h1><font color=blue>Designed by dhara parekh</font></h1>")
def show2(request):
    return render(request,"login.html")
def show3(request):
    return render(request,"home.html")
def show4(request):
    return render(request,"contactus.html")
def show5(request):
    return render(request,"blog.html")
def show6(request):
    return render(request,"aboutus.html")
def show7(request):
    return render(request,"signup.html")
    email = request.GET.get('email')
    email = request.GET.get('psw')
def show8(request):
    return render(request,"hello.html")

def show9(request):
    return render(request,"dashboardM.html")

def adduser(request):
    #model = userforn
    form_class = userform
    return render(request,"userdet.html",{'form': form_class})


def insuser(request):
    user = userdet.objects.all()
    form = userform(request.POST)
    if form.is_valid():
        form.save()
        pass
    return HttpResponse("Record Inserted !!!")
def showuser(request):
    users= userdet.objects.all()
    return render(request,"showusers.html",{'users':users})

def edit(request,id):
    user=userdet.objects.get(id=id)
    return render(request,'edit.html',{'user':user})

def update1(request,id):
    user = userdet.objects.get(id=id)
    form = userform(request.POST, instance=user)
    if form.is_valid():
        form.save()
        return redirect("/showusers")
    return render(request,'edit.html',{'user':user})


def delete1(request,id):
    user=userdet.objects.get(id=id)
    user.delete()
    return redirect("/showusers")


def redirct(param):
    pass



def login2(request):
    if request.method == "POST":
        email = request.POST.get("email")
        password = request.POST.get("password")
        u = auth.authenticate(username=email,password=password)
        if u is None:
            messages.error(request,'invalid user name and password')
            return redirect('/login')
        else:
            auth.login(request,u)
            request.session['email']=email
            return redirect('/dashboardM')
    else:
        return render(request,"hello.html")

def logout(request):
    del request.session['email']
    auth.logout(request)
    return redirect('/')